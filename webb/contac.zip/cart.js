var product = [{
    id:1,
    img:'https://storage.chiangmaibabyshop.com/2021/11/NB_MFPL1-1-300x300.png',
    name:'Nuebabe หมอนเมมโมรี่โฟม แบบกลม',
    price: 319 ,
    description :'Nuebabe หมอนเมมโมรี่โฟม แบบกลม Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet, obcaecati reiciendis. Inventore ullam eligendi aspernatur repellat tenetur modi ea atque quas, doloribus ratione nesciunt odit non excepturi. Mollitia, voluptatum doloribus!',
    type : 'new aaf'
},{
    id:2,
    img:'https://storage.chiangmaibabyshop.com/2022/07/Nuebabe-%E0%B8%AB%E0%B8%A1%E0%B8%AD%E0%B8%99%E0%B8%A3%E0%B8%AD%E0%B8%87%E0%B8%84%E0%B8%AD-%E0%B8%9C%E0%B9%89%E0%B8%B2%E0%B8%99%E0%B8%B8%E0%B9%88%E0%B8%A1-%E0%B8%A3%E0%B8%B0%E0%B8%9A%E0%B8%B2%E0%B8%A2%E0%B8%AD%E0%B8%B2%E0%B8%81%E0%B8%B2%E0%B8%A8%E0%B9%84%E0%B8%94%E0%B9%89%E0%B8%94%E0%B8%B5-Transformers-300x300.png',
    name:'Nuebabe หมอนรองคอ ผ้านุ่ม ระบายอากาศได้ดี Transformers',
    price: 159 ,
    description :'Nuebabe หมอนรองคอ ผ้านุ่ม ระบายอากาศได้ดี Transformers ',
    type : 'newd aaf'
},{
    id:3,
    img:'https://storage.chiangmaibabyshop.com/2022/07/Nuebabe-%E0%B8%AB%E0%B8%A1%E0%B8%AD%E0%B8%99%E0%B9%80%E0%B8%A1%E0%B8%A1%E0%B9%82%E0%B8%A1%E0%B8%A3%E0%B8%B5%E0%B9%88%E0%B9%82%E0%B8%9F%E0%B8%A1-%E0%B8%99%E0%B8%B9%E0%B9%80%E0%B8%9A%E0%B8%9A-300x300.png',
    name:'Nuebabe หมอนเมมโมรี่โฟม',
    price:319 ,
    description:'Nuebabe หมอนเมมโมรี่โฟม  Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet, obcaecati reiciendis. Inventore ullam eligendi aspernatur repellat tenetur modi ea atque quas, doloribus ratione nesciunt odit non excepturi. Mollitia, voluptatum doloribus!',
    type:'new aaf'
},{
    id:4,
    img:'https://storage.chiangmaibabyshop.com/2022/07/Buddy-Babe-%E0%B8%82%E0%B8%A7%E0%B8%94%E0%B8%99%E0%B8%A1%E0%B8%84%E0%B8%AD%E0%B8%81%E0%B8%A7%E0%B9%89%E0%B8%B2%E0%B8%87-8-Oz.-Nuebabe-AA0004-300x300.png',
    name:'Buddy Babe ขวดนมคอกว้าง 8 Oz.',
    price:95 ,
    description:'คอขวดนมมีผิวเรียบด้านในขวดตกไม่แตก สามารถนำไปต้มฆ่าเชื้อโรคที่ความร้อนไม่เกิน 110 องศา ฝาครอบชั้นนอกป้องกันจุกนมให้สะอาดอยู่เสมอ จุกนมซิลิโคนมีวาล์วระบายอากาศคู่ ช่วยระบบการหมุนเวียนอากาศในขวดนม ป้องกันการเกิดอาการโคลิค จุกนมซิลิโคน Size L ฝากเกลียวออกแบบให้สัมผัสกับระบบการหมุนเวียนของอากาศ ควบคุมปริมาณไหลของน้ำนมได้ตามความต้องการ  ปลอดสาร,bpa free',
    type:'newd aab',
},{
    id:5,
    img:'https://storage.chiangmaibabyshop.com/2022/07/Buddy-Babe-%E0%B8%82%E0%B8%A7%E0%B8%94%E0%B8%99%E0%B8%A1%E0%B8%84%E0%B8%AD%E0%B8%81%E0%B8%A7%E0%B9%89%E0%B8%B2%E0%B8%87-4-Oz.-Nuebabe-300x300.png',
    name:'Buddy Babe ขวดนมคอกว้าง 4 Oz.',
    price:89 ,
    description:'ฝากเกลียวออกแบบให้สัมผัสกับระบบการหมุนเวียนของอากาศ ควบคุมปริมาณไหลของน้ำนมได้ตามความต้องการ เมื่อปิดฝาเกลียวแน่นน้ำนมจะไหลน้อยเมื่อปิดหลวมๆน้ำนมจะไหลสะดวกมากขึ้น และปลอดสาร BPA FREE',
    type:'newd aab',
},{
    id:6,
    img:'https://storage.chiangmaibabyshop.com/2021/10/NT_PP521-1.png',
    name:'Natur ขวดนมสมาร์ทไบโอมิมิค PP 5oz แพ็คเกจ 2 ขวด ฟรี 1 ขวด',
    price:449 ,
    description:'ขวดนมคอกว้าง ไหล่ขวดน้อย เทนมสะดวก ล้างขวดง่าย ลดโอกาสสิ่งสกปรกตกค้าง ผลิตจากโพลิโพรพิลิน (PP) ขวดใส พลาสติกเกรดสัมผัสอาหาร ปลอดสาร BPA และ BPS ทนความร้อนได้สูง 110 องศาเซลเซียส ทรงขวดโค้งมน จับถนัดมือ ผลิตภายใต้ระบบบริหารคุณภาพมาตรฐานสากล ISO 9001, GMP และ HACCP (Complies with EN 14350)',
    type:'newd aab',
},{
    id:7,
    img:'https://storage.chiangmaibabyshop.com/2024/02/9aa1d534846ecdab-300x300.jpeg',
    name:'Bebeplay คอกกั้นเด็กเกาหลี (Hug Bear)',
    price:3590,
    description:'คอกกั้นเด็กเกาหลี พรีเมี่ยม สีพาสเทล ช่วยฝึกการทรงตัว การยืน และการเดิน บานประตูสามารถเปิด-ปิด ล็อคจากด้านนอก มีแผ่นกิจกรรมเสริมพัฒนาการ ช่วยบริหารข้อมือ การมองเห็น และความจำ สามารถต่อประกอบได้หลายรูปแบบ เช่น วงกลม ผืนผ้า จตุรัส เป็นต้น เหมาะวางบนพื้นเรียบ เช่น พื้นกระเบื้อง',
    type:'aa'
},{
    id:8,
    img:'https://storage.chiangmaibabyshop.com/2024/02/dea73bb89fa7583e.jpeg',
    name:'Bebeplay แผ่นรองคลานแบบม้วน XPE รุ่น Rolling Mat',
    price:1490,
    description:'เบาะมีความหนา 1.5cm รองรับแรงกระแทกได้ดี ใช้งานสะดวก ม้วนเก็บได้ ประหยัดพื้นที่ มาพร้อมถุงพลาสติกปิคนิคอย่างดีสำหรับพกพา เหมาะสำหรับเด็กอายุ 0-6 เดือน ที่เริ่มฝึกคลาน ใช้สำหรับวางในคอกเด็ก',
    type:'aa'
},{
    id:9,
    img:'https://storage.chiangmaibabyshop.com/2022/07/Nuebabe-%E0%B8%81%E0%B8%A3%E0%B8%B0%E0%B9%82%E0%B8%96%E0%B8%99%E0%B8%99%E0%B8%B1%E0%B9%88%E0%B8%87-%E0%B8%A3%E0%B8%B9%E0%B8%9B%E0%B8%AA%E0%B8%B1%E0%B8%95%E0%B8%A7%E0%B9%8C-%E0%B8%A1%E0%B8%B5%E0%B9%80%E0%B9%80%E0%B8%82%E0%B8%99%E0%B8%88%E0%B8%B1%E0%B8%9A-300x300.png',
    name:'Nuebabe กระโถนนั่ง รูปสัตว์ มีเเขนจับ',
    price:519,
    description:'กระโถนเด็กหัดนั่ง เหมาะสำหรับเด็ก มีคันจับช่วยเบ่ง และป้องกันพลัดตกหกล้ม ผลิตจากพลาสติกคุณภาพดี มีความแข็งแรงทนทาน ทำความสะอาดง่าย',
    type:'aaa'
},{
    id:10,
    img:'https://storage.chiangmaibabyshop.com/2024/02/5308ddf1f0f93b53-300x300.jpg',
    name:'GT Toys เก้าอี้ทานข้าว Safari',
    price:1090,
    description:'เก้าอี้หรับทรงเตี้ย-ทรงสูงได้ มีถาดอาหาร BPA Free 2 ถาด ปรับได้ เข็มขัดนิรภัย 5 สาย โครงสร้างเหล็กและพลาสติก PP แข็งแรง ทนทาน เบาะ PU ทำความสะอาดง่าย',
    type:'aad'
}];

$(document).ready(() => {
    var html = '';
    for(let i=0;i<product.length;i++){
        html += `<div onclick="openproduct(${i})" id="productlis" class="box ${product[i].type}">
                    <img class="img" src="${product[i].img}" alt="">
                     <p style="font-size: 1.2vw">${product[i].name}</p>
                    <p style="font-size: 1vw">${numberWithCommas (product[i].price)}</p>
                </div>`;
    }
    $("#productlis").html(html);
})

function numberWithCommas(x){
    x = x.toString();
    var pattern = /(-?\d+)(\d{3})/;
    while(pattern.test(x))
    x=x.replace(pattern,"$1,$2");
return x;
}

function searchh(elem) {
//console.log(elem.id)
var value = $('#'+elem.id).val()
console.log(value)
var html = '';
for(let i=0;i<product.length;i++){
    if(product[i].name.includes(value)){
         html += `<div onclick="openproduct(${i})" id="productlis" class="box ${product[i].type}">
                     <img class="img" src="${product[i].img}" alt="">
                     <p style="font-size: 1.2vw">${product[i].name}</p>
                     <p style="font-size: 1vw">${numberWithCommas(product[i].price)}</p>
                 </div>`;
    }
}
if(html == ''){
    $("#productlis").html('<p>ไม่พบสินค้า</p>');
}else{
    $("#productlis").html(html);
}
}
function serachproduct(param){
    console.log(param)
    $(".box").css('display','none')
    if(param == 'all'){
        $(".box").css('display','block')
    }
    else{
        $("."+param).css('display','block')
    }
}

var productindex = 0;
function openproduct(index){
    productindex = index;
    console.log(productindex)
    //show modal
    $("#modalDes").css('display','flex')
    $("#mdd-img").attr('src', product[index].img)
    $("#mdd-name").text( product[index].name)
    $("#mdd-price").text( numberWithCommas(product[index].price) + ' THB') 
    $("#mdd-desc").text( product[index].description)
}
//open   ///not show///
function closeModall() {
    $(".modal").css('display','none')
}

/////add
var cart = [];
function addtocart(){
    var pass = true;
    for (let i=0;i<cart.length;i++){
        if(productindex == cart[i].index){
            console.log('found same product')
            cart[i].count++;
            pass = false;
        } 
    }
    //add array and product to cart
    if(pass){
        var obj = {
            index:productindex,
            id: product[productindex].id,
            name: product[productindex].name,
            price: product[productindex].price,
            img: product[productindex].img,
            count: 1
        };
        console.log(obj)
        cart.push(obj)
    }
    console.log(cart)


    Swal.fire({
        icon: 'success',
        title: 'เพิ่ม' + product[productindex].name +  'ลงรถเข็นแล้ว'
    })
    $("#cartcount").css('display','flex').text(cart.length)
}


function opencart(){
    $('#modalcart').css('display','flex')
    rendercart();
}
 //dl class
function rendercart(){
    if(cart.length > 0){
        var html = '';
        for (let i=0; i<cart.length; i++){
            html += `<div class="carlist-item">
                    <div class="box-left">
                    <img class="img-g" src="${cart[i].img}" alt="">
                    <div class="box-detel">
                        <p style="font-size: 1.5vw;">${cart[i].name}</p>
                        <p style="font-size: 1.2vw;">${numberWithCommas(cart[i].price * cart[i].count)} THB</p>
                    </div>
                    </div>
                    <div class="box-right">
                        <p onclick="delistbox('-',${i})" class="bntc">-</p>
                        <p id="countitemm${i}" style="margin: 0 20px;">${cart[i].count}</p>
                        <p onclick="delistbox('+',${i})" class="bntc">+</p>
                    </div>
                    </div>`;
        }
        $("#mycart").html(html)
    }
    else{
        $("#mycart").html(`<p>รถเข็นของคุณว่างเปล่า</p>`)
    }
}
 
function delistbox(action,index){
    if(action == '-') {
        if(cart[index].count > 0){
            cart[index].count--;
            $("#countitemm"+index).text(cart[index].count)

            if(cart[index].count <= 0){
                Swal.fire({
                    icon: 'warning',
                    title: 'ลบสินค้าหรือไม่?' ,
                    showConfirmButton: true,
                    showCancelButton: true,
                    confirmButtonText: 'ลบสินค้า',
                    cancelButtonText: 'ยกเลิก'
                }).then((res) => {
                    if(res.isConfirmed){
                        cart.splice(index,1)
                        console.log(cart)
                        rendercart();
                        $("#cartcount").css('display','flex').text(cart.length)
                        
                        if(cart.length <= 0){
                            $("#cartcount").css('display','none')
                        }
                    }
                    else {
                        cart[index].count++;
                        $("#countitemm"+index).text(cart[index].count)
                    }
                })
            }
        }
    }
    else if(action == '+'){
        cart[index].count++;
        $("#countitemm"+index).text(cart[index].count)
    }

}