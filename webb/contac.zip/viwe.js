var nav = document.querySelector("nav")
navbar.innerHTML = `
            <div class="container">
                <div class="nav-con">
                    <div class="logo"><a href="#">BABY KIDS SHOP</a></div>
                    <ul class="menu">
                        <li><a class="home" href="index.html">Home</a></li>
                        <li><a class="products" href="Produck.html">Products</a></li>
                        <li><a href="contac.html">Contact</a></li>
                        <li><a href="login.html">Login</a></li>
                        <li><a href="favorites.html"><i class="fas fa-heart"></i></a></li>
                        <li><a href=""><i class="fas fa-shopping-cart"></i></a></li>
                    </ul>
                </div>
            </div>
`;